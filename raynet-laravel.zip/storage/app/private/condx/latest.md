UK Propagation Brief — 2025-11-23

Solar/Geo: SFI about 121 sfu, sunspot count ~51. Kp currently ~2–3, forecast for next 24 h Quiet–Unsettled (Kp max ~3–4). Solar wind speed ~400–450 km/s, Bz weak and variable. Radio blackout risk: Low.
Implication: HF propagation mostly normal; no major enhancements.

HF (1.8–30 MHz): Recent ionosonde/MUF charts suggest MUF(3000 km) over UK ~15–18 MHz, peak around 17 MHz. Best daytime bands: 20 m (~14 MHz) and 17 m (~18 MHz) for UK⇄near-Europe. Evening: 40 m (~7 MHz) and 60 m (~5.3 MHz) good for NVIS. D-layer absorption low. Notable path: UK⇄EI/GM/GI on 20 m midday. NVIS window ~08:00–11:00 UTC.

VHF/UHF (50/70/144/432): Tropo/ducting outlook: Low — no high-pressure ridge flagged over UK. Sporadic-E: Very low (off-season). Auroral voice/data: unlikely (Kp < 4). Aircraft scatter/RS: Standard background, no special window.

Digital & Specials: MSK144 meteor scatter – no major shower peaks today. FT8/FT4: 20 m/17 m midday remain best for EU short-path. Satellite/contests: No major alerts or special event passes affecting today.

Liverpool/Merseyside Micro-Note: For Zone 10 (NW England) your best NVIS window is 40 m around 08:30–10:30 local and 60 m from ~14:30–17:30 local; 2 m/70 cm tropo or aurora to EI/GM or North Wales remains negligible today — rely HF.

Actionable Notes:
 - Try 40 m NVIS ~08:00–11:00 UTC for intra-UK nets.
 - Use 20 m/17 m ~12:00–16:00 UTC for UK⇄near-Europe links.
 - Standby 60 m from ~14:00–18:00 UTC for regional fallback.
 - Do not count on sporadic-E or strong tropo openings today.
 - Monitor Kp — if it rises to ≥4 then consider 144 MHz auroral/long-haul options.

Confidence: Medium — UK space-weather and MUF indicators align reasonably, but foF2/MUF data are inferred rather than directly measured for all paths.

Sources:

 • Met Office Space Weather forecast: https://weather.metoffice.gov.uk/specialist-forecasts/space-weather  
 • Kp/aurora forecast: https://www.spaceweatherlive.com/en/auroral-activity/aurora-forecast.html  
 • MUF/ionosonde description: https://www.propquest.co.uk/about.php