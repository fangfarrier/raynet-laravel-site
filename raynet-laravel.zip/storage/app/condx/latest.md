UK Propagation Brief — 2025-11-23

Solar/Geo: [placeholder] This is where the live solar / Kp / SFI summary will go.

HF (1.8–30 MHz): [placeholder] MUF, best bands, NVIS notes, expected absorption, notable paths.

VHF/UHF (50/70/144/432): [placeholder] Tropo/ducting outlook, Es likelihood, aurora chance.

Digital & Specials: [placeholder] MSK144 meteor scatter, FT8/FT4 highlights, satellite/contest notes.

Liverpool/Merseyside Micro-Note: [placeholder] Local NVIS / VHF advice for Zone 10.

Actionable notes:
- [placeholder] Bullet points with what an operator should actually *do* today.

Confidence: [placeholder]

Sources:
- [placeholder list of sites: Met Office Space Weather, W5MMW, Propquest, etc.]