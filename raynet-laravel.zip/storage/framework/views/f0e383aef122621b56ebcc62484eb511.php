<?php $__env->startSection('title', 'Manage Events'); ?>

<?php $__env->startSection('content'); ?>
    <div style="display:flex; justify-content:space-between; align-items:center; gap:1rem;">
        <div>
            <h1>Manage events</h1>
            <p style="color:#9ca3af; font-size:0.9rem; margin-top:0.3rem;">
                Events here drive both the group calendar and the “Next event” card on the home page.
            </p>
        </div>

        <form method="post" action="<?php echo e(route('admin.logout')); ?>">
            <?php echo csrf_field(); ?>
            <button type="submit"
                    style="padding:0.35rem 0.9rem; border-radius:999px;
                           border:1px solid rgba(148,163,184,0.7); background:#020617; color:#e5e7eb;
                           font-size:0.8rem;">
                Log out
            </button>
        </form>
    </div>
<p style="margin:0 0 0.6rem; font-size:0.85rem;">
    <a href="<?php echo e(route('admin.events.export.csv')); ?>" style="color:#93c5fd; text-decoration:none; margin-right:1rem;">
        Export events (CSV) →
    </a>
    <a href="<?php echo e(route('admin.events.import')); ?>" style="color:#a7f3d0; text-decoration:none;">
        Import events from CSV →
    </a>
</p>

    <?php if(session('status')): ?>
        <div style="margin-top:0.9rem; padding:0.75rem 1rem; border-radius:0.5rem;
                    border:1px solid rgba(34,197,94,0.7); background:rgba(22,163,74,0.2); color:#bbf7d0;">
            <?php echo e(session('status')); ?>

        </div>
    <?php endif; ?>

    
    <form method="post" action="<?php echo e(route('admin.events.store')); ?>" style="margin-top:1.2rem; border-radius:0.75rem;
                 border:1px solid rgba(148,163,184,0.4); padding:1rem; background:#020617;">
        <?php echo csrf_field(); ?>

        <h2 style="font-size:1rem; margin:0 0 0.6rem 0;">Add event</h2>

        <?php if($errors->any()): ?>
            <div style="margin-bottom:0.6rem; padding:0.6rem 0.8rem; border-radius:0.5rem;
                        border:1px solid rgba(248,113,113,0.8); background:rgba(127,29,29,0.8); color:#fecaca;">
                <?php echo e($errors->first()); ?>

            </div>
        <?php endif; ?>

        <div style="display:grid; gap:0.7rem; grid-template-columns:repeat(auto-fit,minmax(180px,1fr));">
            <div>
                <label style="display:block; font-size:0.85rem; margin-bottom:0.15rem;">Title *</label>
                <input name="title" type="text"
                       value="<?php echo e(old('title')); ?>"
                       style="width:100%; padding:0.4rem; border-radius:0.4rem;
                              border:1px solid rgba(148,163,184,0.7); background:#020617; color:#e5e7eb;">
            </div>

            <div>
                <label style="display:block; font-size:0.85rem; margin-bottom:0.15rem;">Location</label>
                <input name="location" type="text"
                       value="<?php echo e(old('location')); ?>"
                       style="width:100%; padding:0.4rem; border-radius:0.4rem;
                              border:1px solid rgba(148,163,184,0.7); background:#020617; color:#e5e7eb;">
            </div>

            <div>
                <label style="display:block; font-size:0.85rem; margin-bottom:0.15rem;">Start (date &amp; time) *</label>
                <input name="starts_at" type="datetime-local"
                       value="<?php echo e(old('starts_at')); ?>"
                       style="width:100%; padding:0.4rem; border-radius:0.4rem;
                              border:1px solid rgba(148,163,184,0.7); background:#020617; color:#e5e7eb;">
            </div>

            <div>
                <label style="display:block; font-size:0.85rem; margin-bottom:0.15rem;">Ends (date &amp; time)</label>
                <input name="ends_at" type="datetime-local"
                       value="<?php echo e(old('ends_at')); ?>"
                       style="width:100%; padding:0.4rem; border-radius:0.4rem;
                              border:1px solid rgba(148,163,184,0.7); background:#020617; color:#e5e7eb;">
            </div>

            <div>
                <label style="display:block; font-size:0.85rem; margin-bottom:0.15rem;">Event type *</label>
                <select name="event_type_id"
                        style="width:100%; padding:0.4rem; border-radius:0.4rem;
                               border:1px solid rgba(148,163,184,0.7); background:#020617; color:#e5e7eb;">
                    <option value="">Select type…</option>
                    <?php $__currentLoopData = $types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($type->id); ?>"
                            <?php echo e(old('event_type_id') == $type->id ? 'selected' : ''); ?>>
                            <?php echo e($type->name); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
        </div>

        <button type="submit"
                style="margin-top:0.9rem; padding:0.4rem 1.1rem; border-radius:999px;
                       border:1px solid rgba(56,189,248,0.9); background:#020617; color:#e5e7eb; font-size:0.85rem;">
            Save event
        </button>
    </form>

    
    <div style="margin-top:1.2rem; border-radius:0.75rem; overflow:hidden;
                border:1px solid rgba(148,163,184,0.4); background:#020617;">
        <table style="width:100%; border-collapse:collapse; font-size:0.85rem; table-layout:fixed;">

            <colgroup>
                <col style="width:32%;">  
                <col style="width:18%;">  
                <col style="width:20%;">  
                <col style="width:14%;">  
                <col style="width:16%;">  
            </colgroup>

            <thead style="background:#020617; border-bottom:1px solid rgba(31,41,55,0.9);">
                <tr>
                    <th style="text-align:left; padding:0.55rem 0.75rem;">Title</th>
                    <th style="text-align:left; padding:0.55rem 0.75rem;">When</th>
                    <th style="text-align:left; padding:0.55rem 0.75rem;">Location</th>
                    <th style="text-align:left; padding:0.55rem 0.75rem;">Type</th>
                    <th style="text-align:right; padding:0.55rem 0.75rem;">Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr style="border-top:1px solid rgba(31,41,55,0.9);">
                        <td style="padding:0.55rem 0.75rem; color:#e5e7eb;">
                            <?php echo e($event->title); ?>

                        </td>
                        <td style="padding:0.55rem 0.75rem; color:#9ca3af;">
                            <?php echo e(method_exists($event, 'displayDate') ? $event->displayDate() : $event->starts_at); ?>

                        </td>
                        <td style="padding:0.55rem 0.75rem; color:#9ca3af;">
                            <?php echo e($event->location ?? '—'); ?>

                        </td>
                        <td style="padding:0.55rem 0.75rem; color:#9ca3af;">
                            <?php
                                $type        = $event->type;
                                $badgeLabel  = $type?->name ?? '—';
                                $badgeColour = $type?->colour ?: 'rgba(31,41,55,1)';
                            ?>
                            <span style="
                                display:inline-block;
                                padding:0.1rem 0.6rem;
                                border-radius:999px;
                                background: <?php echo e($badgeColour); ?>;
                                color:#e5e7eb;
                                font-size:0.75rem;
                                white-space:nowrap;
                            ">
                                <?php echo e($badgeLabel); ?>

                            </span>
                        </td>
                        <td style="padding:0.55rem 0.75rem; text-align:right; white-space:nowrap;">
                            <a href="<?php echo e($event->url()); ?>"
                               target="_blank"
                               style="color:#93c5fd; text-decoration:none; font-size:0.8rem; margin-right:0.75rem;">
                                View
                            </a>
                            <a href="<?php echo e(route('admin.events.delete', $event->id)); ?>"
                               onclick="return confirm('Delete this event?');"
                               style="color:#fca5a5; text-decoration:none; font-size:0.8rem;">
                                Delete
                            </a>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="5" style="padding:0.7rem 0.75rem; color:#9ca3af;">
                            No events added yet. Use the form above to create one.
                        </td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>

        <?php if($events->lastPage() > 1): ?>
            <?php
                $current = $events->currentPage();
                $last    = $events->lastPage();
            ?>

            <nav aria-label="Event pagination"
                 style="margin-top:0.5rem; padding:0.5rem 0.75rem 0.75rem;
                        display:flex; justify-content:space-between; align-items:center;
                        gap:1rem; font-size:0.85rem; color:#e5e7eb;">

                <div style="display:flex; align-items:center; gap:0.35rem;">
                    <?php if($current === 1): ?>
                        <span style="opacity:0.4;">&lt;</span>
                    <?php else: ?>
                        <a href="<?php echo e($events->url($current - 1)); ?>"
                           rel="prev"
                           style="text-decoration:none; color:#93c5fd;">
                            &lt;
                        </a>
                    <?php endif; ?>

                    <?php for($page = 1; $page <= $last; $page++): ?>
                        <?php if($page === $current): ?>
                            <span style="font-weight:600; color:#e5e7eb; border-bottom:1px solid #e5e7eb;">
                                <?php echo e($page); ?>

                            </span>
                        <?php else: ?>
                            <a href="<?php echo e($events->url($page)); ?>"
                               style="text-decoration:none; color:#a855f7;">
                                <?php echo e($page); ?>

                            </a>
                        <?php endif; ?>
                    <?php endfor; ?>

                    <?php if($current === $last): ?>
                        <span style="opacity:0.4;">&gt;</span>
                    <?php else: ?>
                        <a href="<?php echo e($events->url($current + 1)); ?>"
                           rel="next"
                           style="text-decoration:none; color:#93c5fd;">
                            &gt;
                        </a>
                    <?php endif; ?>
                </div>

                <div style="color:#9ca3af;">
                    Showing
                    <?php echo e($events->firstItem()); ?>

                    to
                    <?php echo e($events->lastItem()); ?>

                    of
                    <?php echo e($events->total()); ?>

                    results
                </div>
            </nav>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/ianjones/raynet-site/resources/views/admin/events/index.blade.php ENDPATH**/ ?>