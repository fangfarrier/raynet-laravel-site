<?php $__env->startSection('title', 'Manage operators'); ?>

<?php $__env->startSection('content'); ?>
    <div style="display:flex; justify-content:space-between; align-items:center; gap:1rem;">
        <div>
            <h1>Manage operators</h1>
            <p style="color:#9ca3af; font-size:0.9rem; margin-top:0.3rem;">
                This is my master list of Liverpool RAYNET operators – callsigns, roles, levels, statuses and admin flags.
            </p>
        </div>

        <a href="<?php echo e(route('admin.dashboard')); ?>"
           style="padding:0.35rem 0.9rem; border-radius:999px;
                  border:1px solid rgba(148,163,184,0.7); background:#020617;
                  color:#e5e7eb; font-size:0.8rem; text-decoration:none;">
            ← Back to admin
        </a>
    </div>

    <?php if(session('status')): ?>
        <div style="margin-top:0.9rem; padding:0.75rem 1rem; border-radius:0.5rem;
                    border:1px solid rgba(34,197,94,0.7); background:rgba(22,163,74,0.2); color:#bbf7d0;">
            <?php echo e(session('status')); ?>

        </div>
    <?php endif; ?>

    <?php
        /** @var \App\Models\Operator|null $editingOperator */
        /** @var \Illuminate\Support\Collection|\App\Models\Role[] $roles */
        $statuses        = ['Active', 'Training', 'On hold', 'Inactive'];
        $currentRole     = old('role', $editingOperator->role ?? '');
        $hasRolesDefined = $roles->isNotEmpty();
        // Map role name → colour so I can tint the table cells
        $roleColours     = $roles->pluck('colour', 'name');
    ?>

    
    <form method="post"
          action="<?php echo e(isset($editingOperator)
                        ? route('admin.operators.update', $editingOperator->id)
                        : route('admin.operators.store')); ?>"
          style="margin-top:1.2rem; border-radius:0.75rem;
                 border:1px solid rgba(148,163,184,0.4); padding:1rem; background:#020617;">
        <?php echo csrf_field(); ?>
        <?php if(isset($editingOperator)): ?>
            <?php echo method_field('PUT'); ?>
        <?php endif; ?>

        <h2 style="font-size:1rem; margin:0 0 0.6rem 0;">
            <?php echo e(isset($editingOperator) ? 'Edit operator' : 'Add operator'); ?>

        </h2>

        <?php if(isset($editingOperator)): ?>
            <p style="margin:0 0 0.5rem; font-size:0.8rem; color:#9ca3af;">
                Editing: <strong><?php echo e($editingOperator->name); ?></strong> (<?php echo e($editingOperator->callsign); ?>).
                <a href="<?php echo e(route('admin.operators')); ?>" style="color:#93c5fd;">Cancel edit</a>
            </p>
        <?php endif; ?>

        <?php if($errors->any()): ?>
            <div style="margin-bottom:0.6rem; padding:0.6rem 0.8rem; border-radius:0.5rem;
                        border:1px solid rgba(248,113,113,0.8); background:rgba(127,29,29,0.8); color:#fecaca;">
                <?php echo e($errors->first()); ?>

            </div>
        <?php endif; ?>

        <div style="display:grid; gap:0.7rem; grid-template-columns:repeat(auto-fit,minmax(200px,1fr));">
            
            <div>
                <label style="display:block; font-size:0.85rem; margin-bottom:0.15rem;">Name *</label>
                <input name="name" type="text"
                       value="<?php echo e(old('name', $editingOperator->name ?? '')); ?>"
                       placeholder="Ian Jones"
                       style="width:100%; padding:0.4rem; border-radius:0.4rem;
                              border:1px solid rgba(148,163,184,0.7); background:#020617; color:#e5e7eb;">
            </div>

            
            <div>
                <label style="display:block; font-size:0.85rem; margin-bottom:0.15rem;">Callsign</label>
                <input name="callsign" type="text"
                       value="<?php echo e(old('callsign', $editingOperator->callsign ?? '')); ?>"
                       placeholder="G4BDS"
                       style="width:100%; padding:0.4rem; border-radius:0.4rem;
                              border:1px solid rgba(148,163,184,0.7); background:#020617; color:#e5e7eb;">
            </div>

            
            <div>
                <label style="display:block; font-size:0.85rem; margin-bottom:0.15rem;">Role</label>

                <?php if($hasRolesDefined): ?>
                    <select name="role"
                            style="width:100%; padding:0.4rem; border-radius:0.4rem;
                                   border:1px solid rgba(148,163,184,0.7); background:#020617; color:#e5e7eb;">
                        <option value="">— Select role —</option>
                        <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($role->name); ?>" <?php echo e($currentRole === $role->name ? 'selected' : ''); ?>>
                                <?php echo e($role->name); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <p style="margin:0.25rem 0 0; font-size:0.75rem; color:#6b7280;">
                        Need to change the list? Use the
                        <a href="<?php echo e(route('admin.roles')); ?>" style="color:#93c5fd;">Roles screen</a>.
                    </p>
                <?php else: ?>
                    <input name="role" type="text"
                           value="<?php echo e($currentRole); ?>"
                           placeholder="Group Controller, Operator…"
                           style="width:100%; padding:0.4rem; border-radius:0.4rem;
                                  border:1px solid rgba(148,163,184,0.7); background:#020617; color:#e5e7eb;">
                    <p style="margin:0.25rem 0 0; font-size:0.75rem; color:#f97316;">
                        No roles defined yet. I can create them under
                        <a href="<?php echo e(route('admin.roles')); ?>" style="color:#fdba74;">Admin → Roles</a>.
                    </p>
                <?php endif; ?>
            </div>

            
            <div>
                <label style="display:block; font-size:0.85rem; margin-bottom:0.15rem;">Level</label>
                <input name="level" type="text"
                       value="<?php echo e(old('level', $editingOperator->level ?? '')); ?>"
                       placeholder="Level 0–5"
                       style="width:100%; padding:0.4rem; border-radius:0.4rem;
                              border:1px solid rgba(148,163,184,0.7); background:#020617; color:#e5e7eb;">
            </div>

            
            <div>
                <label style="display:block; font-size:0.85rem; margin-bottom:0.15rem;">Status *</label>
                <select name="status"
                        style="width:100%; padding:0.4rem; border-radius:0.4rem;
                               border:1px solid rgba(148,163,184,0.7); background:#020617; color:#e5e7eb;">
                    <?php
                        $currentStatus = old('status', $editingOperator->status ?? 'Active');
                    ?>
                    <?php $__currentLoopData = $statuses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($status); ?>" <?php echo e($currentStatus === $status ? 'selected' : ''); ?>>
                            <?php echo e($status); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>

            
            <div style="display:flex; align-items:flex-end; gap:0.35rem;">
                <label style="font-size:0.85rem;">
                    <input type="checkbox" name="is_admin" value="1"
                           <?php echo e(old('is_admin', $editingOperator->is_admin ?? false) ? 'checked' : ''); ?>>
                    <span style="margin-left:0.3rem;">Has admin access</span>
                </label>
            </div>
        </div>

        <div style="margin-top:0.9rem;">
            <button type="submit"
                    style="padding:0.45rem 0.9rem; border-radius:999px;
                           border:none; background:#22c55e; color:#020617;
                           font-size:0.85rem; font-weight:600; cursor:pointer;">
                <?php echo e(isset($editingOperator) ? 'Update operator' : 'Save operator'); ?>

            </button>
        </div>
    </form>

    
    <section style="margin-top:1.3rem;">
        <h2 style="font-size:0.95rem; margin:0 0 0.5rem;">Operator list</h2>

        <?php if($operators->isEmpty()): ?>
            <p style="font-size:0.8rem; color:#9ca3af;">
                No operators yet. Once I add records above, they’ll show here.
            </p>
        <?php else: ?>
            <div style="
                border-radius:0.8rem;
                border:1px solid rgba(148,163,184,0.5);
                background:#020617;
                overflow:hidden;
                font-size:0.8rem;
            ">
                <table style="width:100%; border-collapse:collapse;">
                    <thead>
                    <tr style="background:#020617; color:#9ca3af; text-align:left;">
                        <th style="padding:0.55rem 0.75rem;">Name</th>
                        <th style="padding:0.55rem 0.75rem;">Callsign</th>
                        <th style="padding:0.55rem 0.75rem;">Role</th>
                        <th style="padding:0.55rem 0.75rem;">Level</th>
                        <th style="padding:0.55rem 0.75rem;">Status</th>
                        <th style="padding:0.55rem 0.75rem;">Admin</th>
                        <th style="padding:0.55rem 0.75rem; text-align:right;">Actions</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php $__currentLoopData = $operators; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $operator): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                            $roleName   = $operator->role;
                            $roleColour = $roleName ? ($roleColours[$roleName] ?? null) : null;
                        ?>
                        <tr style="border-top:1px solid rgba(31,41,55,0.95);">
                            <td style="padding:0.5rem 0.75rem;">
                                <?php echo e($operator->name); ?>

                            </td>
                            <td style="padding:0.5rem 0.75rem;">
                                <?php echo e($operator->callsign); ?>

                            </td>
                            <td style="padding:0.5rem 0.75rem;">
                                <?php if($roleName && $roleColour): ?>
                                    <span style="
                                        display:inline-flex;
                                        align-items:center;
                                        gap:0.4rem;
                                        padding:0.12rem 0.45rem;
                                        border-radius:999px;
                                        border:1px solid <?php echo e($roleColour); ?>;
                                        background: <?php echo e($roleColour); ?>1a;
                                        font-size:0.75rem;
                                    ">
                                        <span style="
                                            width:9px;
                                            height:9px;
                                            border-radius:999px;
                                            background: <?php echo e($roleColour); ?>;
                                            box-shadow:0 0 0 2px rgba(15,23,42,0.9);
                                        "></span>
                                        <span><?php echo e($roleName); ?></span>
                                    </span>
                                <?php else: ?>
                                    <?php echo e($roleName ?: '–'); ?>

                                <?php endif; ?>
                            </td>
                            <td style="padding:0.5rem 0.75rem;">
                                <?php echo e($operator->level); ?>

                            </td>
                            <td style="padding:0.5rem 0.75rem;">
                                <?php echo e($operator->status); ?>

                            </td>
                            <td style="padding:0.5rem 0.75rem;">
                                <?php if($operator->is_admin): ?>
                                    <span style="padding:0.12rem 0.4rem; border-radius:999px;
                                                 background:rgba(168,85,247,0.25);
                                                 border:1px solid rgba(168,85,247,0.9);
                                                 font-size:0.72rem;">
                                        Admin
                                    </span>
                                <?php endif; ?>
                            </td>
                            <td style="padding:0.5rem 0.75rem; text-align:right;">
                                <a href="<?php echo e(route('admin.operators', ['edit' => $operator->id])); ?>"
                                   style="margin-right:0.5rem; color:#93c5fd; text-decoration:none;">
                                    Edit
                                </a>
                                <a href="<?php echo e(route('admin.operators.delete', $operator->id)); ?>"
                                   style="color:#fca5a5; text-decoration:none;"
                                   onclick="return confirm('Delete this operator record?');">
                                    Delete
                                </a>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>

            <div class="admin-pagination">
                <?php echo e($operators->links()); ?>

            </div>
        <?php endif; ?>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/ianjones/raynet-site/resources/views/admin/operators/index.blade.php ENDPATH**/ ?>