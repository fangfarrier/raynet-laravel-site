<?php $__env->startSection('title', 'Training'); ?>

<?php $__env->startSection('content'); ?>
    <h1>Training & Exercises</h1>
    <p>
        Liverpool RAYNET runs structured training covering radio procedure, net control, mapping & navigation,
        digital modes and working under JESIP principles. We combine on-air nets, classroom-style sessions and
        practical field exercises.
    </p>
    <p>
        Future versions of this site will link to an online training portal and publish the current training plan.
    </p>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/ianjones/raynet-site/resources/views/pages/training.blade.php ENDPATH**/ ?>