<?php $__env->startSection('title', 'My Profile'); ?>

<?php $__env->startSection('content'); ?>

    <?php
        // Short-hands for the view, so we don’t keep typing $user->...
        /** @var \App\Models\User $user */
        $userName    = $user->name;
        $userEmail   = $user->email;
        $userCallsign = $user->callsign;
    ?>

    
    <section style="margin-bottom: 1.5rem;">
        <h1 style="margin:0 0 0.4rem; font-size:1.25rem; color:#e5e7eb;">
            My profile
        </h1>
        <p style="margin:0; font-size:0.9rem; color:#9ca3af;">
            Manage how I appear in Liverpool RAYNET systems – name, callsign and account details.
        </p>
    </section>

    
    <?php if(session('status')): ?>
        <div style="
            margin-bottom:0.9rem;
            padding:0.6rem 0.8rem;
            border-radius:0.75rem;
            border:1px solid rgba(34,197,94,0.7);
            background:rgba(22,163,74,0.18);
            color:#bbf7d0;
            font-size:0.85rem;
        ">
            <?php echo e(session('status')); ?>

        </div>
    <?php endif; ?>

    <?php if($errors->any()): ?>
        <div style="
            margin-bottom:0.9rem;
            padding:0.6rem 0.8rem;
            border-radius:0.75rem;
            border:1px solid rgba(248,113,113,0.7);
            background:rgba(220,38,38,0.18);
            color:#fecaca;
            font-size:0.85rem;
        ">
            <strong style="display:block; margin-bottom:0.3rem;">Please fix the following:</strong>
            <ul style="margin:0; padding-left:1.2rem;">
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    
    <section style="
        display:flex;
        flex-wrap:wrap;
        gap:1.4rem;
        align-items:flex-start;
    ">
        
        <article style="
            flex:1 1 320px;
            border-radius:1rem;
            border:1px solid rgba(148,163,184,0.5);
            background:rgba(15,23,42,0.96);
            padding:1rem 1.2rem 1rem;
            font-size:0.9rem;
            color:#e5e7eb;
        ">
            <h2 style="margin:0 0 0.6rem; font-size:1rem; color:#e5e7eb;">
                Profile details
            </h2>
            <p style="margin:0 0 0.7rem; font-size:0.8rem; color:#9ca3af;">
                These details are used across the members’ hub, event rosters and training systems.
            </p>

            <form method="POST" action="<?php echo e(route('profile.update')); ?>" style="margin-top:0.4rem;">
                <?php echo csrf_field(); ?>

                
                <div style="margin-bottom:0.7rem;">
                    <label for="name" style="display:block; font-size:0.82rem; margin-bottom:0.15rem;">
                        Full name
                    </label>
                    <input
                        id="name"
                        name="name"
                        type="text"
                        value="<?php echo e(old('name', $userName)); ?>"
                        required
                        style="
                            width:100%;
                            padding:0.45rem 0.55rem;
                            border-radius:0.6rem;
                            border:1px solid rgba(148,163,184,0.7);
                            background:#020617;
                            color:#e5e7eb;
                            font-size:0.9rem;
                        "
                    >
                    <p style="margin:0.2rem 0 0; font-size:0.75rem; color:#6b7280;">
                        This is how your name appears on members’ pages and admin lists.
                    </p>
                </div>

                
                <div style="margin-bottom:0.7rem;">
                    <label for="email" style="display:block; font-size:0.82rem; margin-bottom:0.15rem;">
                        Email address
                    </label>
                    <input
                        id="email"
                        type="email"
                        value="<?php echo e($userEmail); ?>"
                        disabled
                        style="
                            width:100%;
                            padding:0.45rem 0.55rem;
                            border-radius:0.6rem;
                            border:1px dashed rgba(148,163,184,0.5);
                            background:#020617;
                            color:#9ca3af;
                            font-size:0.9rem;
                            opacity:0.85;
                        "
                    >
                    <p style="margin:0.2rem 0 0; font-size:0.75rem; color:#6b7280;">
                        Login email is managed by an administrator for now.
                    </p>
                </div>

                
                <div style="margin-bottom:0.9rem;">
                    <label for="callsign" style="display:block; font-size:0.82rem; margin-bottom:0.15rem;">
                        Callsign
                    </label>
                    <input
                        id="callsign"
                        name="callsign"
                        type="text"
                        value="<?php echo e(old('callsign', $userCallsign)); ?>"
                        placeholder="e.g. G4BDS"
                        style="
                            width:100%;
                            padding:0.45rem 0.55rem;
                            border-radius:0.6rem;
                            border:1px solid rgba(96,165,250,0.9);
                            background:#020617;
                            color:#e5e7eb;
                            font-size:0.9rem;
                            text-transform:uppercase;
                        "
                    >
                    <p style="margin:0.2rem 0 0; font-size:0.75rem; color:#6b7280;">
                        Optional, but recommended. 3–10 characters, letters/numbers/slash only.
                        Used for logging and event paperwork.
                    </p>
                </div>

                
                <div style="display:flex; flex-wrap:wrap; gap:0.6rem; align-items:center;">
                    <button type="submit" style="
                        padding:0.45rem 0.95rem;
                        border-radius:999px;
                        border:none;
                        background:linear-gradient(to right,#38bdf8,#0ea5e9);
                        color:#020617;
                        font-size:0.9rem;
                        font-weight:600;
                        cursor:pointer;
                    ">
                        Save changes
                    </button>

                    <a href="<?php echo e(route('password.change')); ?>"
                       style="font-size:0.8rem; color:#93c5fd; text-decoration:none;">
                        Change my password →
                    </a>
                </div>
            </form>
        </article>

        
        <article style="
            flex:0 0 280px;
            max-width:320px;
            border-radius:1rem;
            border:1px solid rgba(148,163,184,0.5);
            background:radial-gradient(circle at top left,#020617,#020617 60%,#020617 100%);
            padding:1rem 1rem 0.9rem;
            font-size:0.85rem;
            color:#e5e7eb;
        ">
            <h2 style="margin:0 0 0.5rem; font-size:1rem;">
                Account summary
            </h2>

            <p style="margin:0 0 0.6rem; font-size:0.8rem; color:#9ca3af;">
                Quick snapshot of how this account is seen by Liverpool RAYNET systems.
            </p>

            <dl style="margin:0; font-size:0.83rem;">
                <div style="margin-bottom:0.4rem;">
                    <dt style="font-size:0.78rem; text-transform:uppercase; letter-spacing:0.08em; color:#6b7280;">
                        Name
                    </dt>
                    <dd style="margin:0; font-weight:500;">
                        <?php echo e($userName); ?>

                    </dd>
                </div>

                <div style="margin-bottom:0.4rem;">
                    <dt style="font-size:0.78rem; text-transform:uppercase; letter-spacing:0.08em; color:#6b7280;">
                        Email
                    </dt>
                    <dd style="margin:0;">
                        <?php echo e($userEmail); ?>

                    </dd>
                </div>

                <div style="margin-bottom:0.4rem;">
                    <dt style="font-size:0.78rem; text-transform:uppercase; letter-spacing:0.08em; color:#6b7280;">
                        Callsign
                    </dt>
                    <dd style="margin:0;">
                        <?php echo e($userCallsign ?: 'Not set'); ?>

                    </dd>
                </div>

                <div style="margin-bottom:0.4rem;">
                    <dt style="font-size:0.78rem; text-transform:uppercase; letter-spacing:0.08em; color:#6b7280;">
                        Member since
                    </dt>
                    <dd style="margin:0;">
                        <?php echo e(optional($user->created_at)->format('d M Y') ?? 'Unknown'); ?>

                    </dd>
                </div>
            </dl>

            <p style="margin:0.8rem 0 0; font-size:0.78rem; color:#6b7280;">
                Over time this panel can pull in your training level, exercise history
                and typical deployment roles so controllers get an instant picture.
            </p>
        </article>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/ianjones/raynet-site/resources/views/profile/edit.blade.php ENDPATH**/ ?>