<?php $__env->startSection('title', 'Event types'); ?>

<?php $__env->startSection('content'); ?>
    <div style="display:flex; justify-content:space-between; align-items:center; gap:1rem;">
        <div>
            <h1>Event types</h1>
            <p style="color:#9ca3af; font-size:0.9rem; margin-top:0.3rem;">
                Use event types to keep your calendar consistent – e.g. Training, Event support, Exercise, Meeting.
                You can also set the colour used for badges on the calendar.
            </p>
        </div>

        <a href="<?php echo e(route('admin.events')); ?>"
           style="padding:0.35rem 0.9rem; border-radius:999px;
                  border:1px solid rgba(148,163,184,0.7); background:#020617;
                  color:#e5e7eb; font-size:0.8rem; text-decoration:none;">
            ← Back to events
        </a>
    </div>

    <?php if(session('status')): ?>
        <div style="margin-top:0.9rem; padding:0.75rem 1rem; border-radius:0.5rem;
                    border:1px solid rgba(34,197,94,0.7); background:rgba(22,163,74,0.2); color:#bbf7d0;">
            <?php echo e(session('status')); ?>

        </div>
    <?php endif; ?>

    
    <?php
        /** @var \App\Models\EventType|null $editingType */
        $currentColour = old('colour', $editingType->colour ?? '#22c55e');
    ?>

    <form method="post"
          action="<?php echo e(isset($editingType)
                        ? route('admin.event-types.update', $editingType->id)
                        : route('admin.event-types.store')); ?>"
          style="margin-top:1.2rem; border-radius:0.75rem;
                 border:1px solid rgba(148,163,184,0.4); padding:1rem; background:#020617;">
        <?php echo csrf_field(); ?>
        <?php if(isset($editingType)): ?>
            <?php echo method_field('PUT'); ?>
        <?php endif; ?>

        <h2 style="font-size:1rem; margin:0 0 0.6rem 0;">
            <?php echo e(isset($editingType) ? 'Edit event type' : 'Add event type'); ?>

        </h2>

        <?php if(isset($editingType)): ?>
            <p style="margin:0 0 0.5rem; font-size:0.8rem; color:#9ca3af;">
                Editing: <strong><?php echo e($editingType->name); ?></strong>.
                <a href="<?php echo e(route('admin.event-types')); ?>" style="color:#93c5fd;">Cancel edit</a>
            </p>
        <?php endif; ?>

        <?php if($errors->any()): ?>
            <div style="margin-bottom:0.6rem; padding:0.6rem 0.8rem; border-radius:0.5rem;
                        border:1px solid rgba(248,113,113,0.8); background:rgba(127,29,29,0.8); color:#fecaca;">
                <?php echo e($errors->first()); ?>

            </div>
        <?php endif; ?>

        <div style="display:grid; gap:0.7rem; grid-template-columns:repeat(auto-fit,minmax(180px,1fr));">
            
            <div>
                <label style="display:block; font-size:0.85rem; margin-bottom:0.15rem;">Name *</label>
                <input name="name" type="text"
                       value="<?php echo e(old('name', $editingType->name ?? '')); ?>"
                       placeholder="Training, Event support, Exercise…"
                       style="width:100%; padding:0.4rem; border-radius:0.4rem;
                              border:1px solid rgba(148,163,184,0.7); background:#020617; color:#e5e7eb;">
            </div>

            
            <div>
                <label style="display:block; font-size:0.85rem; margin-bottom:0.15rem;">Sort order</label>
                <input name="sort_order" type="number"
                       value="<?php echo e(old('sort_order', $editingType->sort_order ?? 0)); ?>"
                       style="width:100%; padding:0.4rem; border-radius:0.4rem;
                              border:1px solid rgba(148,163,184,0.7); background:#020617; color:#e5e7eb;">
                <p style="margin:0.25rem 0 0; font-size:0.75rem; color:#9ca3af;">
                    Lower numbers appear first.
                </p>
            </div>

            
            <div>
                <label style="display:block; font-size:0.85rem; margin-bottom:0.15rem;">Badge colour</label>

                <div style="display:flex; align-items:center; gap:0.5rem; margin-bottom:0.35rem;">
                    
                    <input id="colourPicker" type="color"
                           value="<?php echo e($currentColour); ?>"
                           style="width:40px; height:32px; padding:0; border-radius:0.4rem;
                                  border:1px solid rgba(148,163,184,0.7); background:#020617;">
                    
                    <input id="colourInput" name="colour" type="text"
                           value="<?php echo e(old('colour', $editingType->colour ?? '')); ?>"
                           placeholder="#22c55e"
                           style="flex:1; padding:0.4rem; border-radius:0.4rem;
                                  border:1px solid rgba(148,163,184,0.7); background:#020617; color:#e5e7eb;">

                    
                    <div id="colourPreview"
                         style="width:32px; height:24px; border-radius:0.4rem;
                                border:1px solid rgba(148,163,184,0.7);
                                background: <?php echo e($currentColour); ?>;">
                    </div>
                </div>

                <div style="display:flex; align-items:center; gap:0.5rem;">
                    <button type="button"
                            id="resetColourButton"
                            style="padding:0.2rem 0.7rem; border-radius:999px;
                                   border:1px solid rgba(148,163,184,0.7);
                                   background:#020617; color:#e5e7eb; font-size:0.75rem;">
                        Reset to default
                    </button>
                    <p style="margin:0; font-size:0.75rem; color:#9ca3af;">
                        Optional hex colour (e.g. <code>#22c55e</code>). Leave blank for default.
                    </p>
                </div>
            </div>
        </div>

        <button type="submit"
                style="margin-top:0.9rem; padding:0.4rem 1.1rem; border-radius:999px;
                       border:1px solid rgba(56,189,248,0.9); background:#020617; color:#e5e7eb; font-size:0.85rem;">
            <?php echo e(isset($editingType) ? 'Update type' : 'Save type'); ?>

        </button>
    </form>

    
    <div style="margin-top:1.2rem; border-radius:0.75rem; overflow:hidden;
                border:1px solid rgba(148,163,184,0.4); background:#020617;">
        <table style="width:100%; border-collapse:collapse; font-size:0.85rem;">
            <thead style="background:#020617; border-bottom:1px solid rgba(31,41,55,0.9);">
                <tr>
                    <th style="text-align:left; padding:0.55rem 0.75rem;">Name</th>
                    <th style="text-align:left; padding:0.55rem 0.75rem;">Slug</th>
                    <th style="text-align:left; padding:0.55rem 0.75rem;">Sort order</th>
                    <th style="text-align:left; padding:0.55rem 0.75rem;">Colour</th>
                    <th style="text-align:right; padding:0.55rem 0.75rem;">Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <?php
                        $colour = $type->colour ?: '#4b5563';
                    ?>

                    <tr style="border-top:1px solid rgba(31,41,55,0.9);">
                        <td style="padding:0.55rem 0.75rem; color:#e5e7eb;">
                            <?php echo e($type->name); ?>

                        </td>

                        <td style="padding:0.55rem 0.75rem; color:#9ca3af;">
                            <?php echo e($type->slug); ?>

                        </td>

                        <td style="padding:0.55rem 0.75rem; color:#9ca3af;">
                            <?php echo e($type->sort_order); ?>

                        </td>

                        <td style="padding:0.55rem 0.75rem;">
                            <span style="
                                display:inline-flex;
                                align-items:center;
                                gap:0.4rem;
                                padding:0.1rem 0.45rem;
                                border-radius:999px;
                                border:1px solid <?php echo e($colour); ?>;
                                background: <?php echo e($colour); ?>1a;
                                font-size:0.78rem;
                                color:#e5e7eb;
                            ">
                                <span style="width:10px; height:10px; border-radius:999px; background:<?php echo e($colour); ?>;"></span>
                                <?php echo e($type->colour ?: 'Default'); ?>

                            </span>
                        </td>

                        <td style="padding:0.55rem 0.75rem; text-align:right; white-space:nowrap;">
                            <a href="<?php echo e(route('admin.event-types', ['edit' => $type->id])); ?>"
                               style="color:#93c5fd; text-decoration:none; font-size:0.8rem; margin-right:0.75rem;">
                                Edit
                            </a>

                            <a href="<?php echo e(route('admin.event-types.delete', $type->id)); ?>"
                               onclick="return confirm('Delete this event type?');"
                               style="color:#fca5a5; text-decoration:none; font-size:0.8rem;">
                                Delete
                            </a>
                        </td>
                    </tr>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="5" style="padding:0.7rem 0.75rem; color:#9ca3af;">
                            No event types yet. Add your first type above.
                        </td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

    
    <script>
        (function () {
            const picker  = document.getElementById('colourPicker');
            const input   = document.getElementById('colourInput');
            const preview = document.getElementById('colourPreview');
            const reset   = document.getElementById('resetColourButton');

            if (!picker || !input || !preview || !reset) {
                return;
            }

            const defaultColour = '#22c55e';

            function normaliseHex(value) {
                if (!value) return '';
                value = value.trim();
                if (!value) return '';
                if (value[0] !== '#') value = '#' + value;
                if (!/^#[0-9a-fA-F]{3,6}$/.test(value)) return '';
                // expand #abc -> #aabbcc
                if (value.length === 4) {
                    value = '#' + value[1] + value[1] + value[2] + value[2] + value[3] + value[3];
                }
                return value.slice(0, 7).toLowerCase();
            }

            function applyColour(hex) {
                if (!hex) {
                    // fallback to default preview, empty input
                    input.value = '';
                    picker.value = defaultColour;
                    preview.style.background = defaultColour;
                    return;
                }
                input.value = hex;
                picker.value = hex;
                preview.style.background = hex;
            }

            picker.addEventListener('input', function () {
                const hex = normaliseHex(picker.value);
                applyColour(hex || defaultColour);
            });

            input.addEventListener('blur', function () {
                const hex = normaliseHex(input.value);
                if (!hex) {
                    applyColour('');
                } else {
                    applyColour(hex);
                }
            });

            reset.addEventListener('click', function () {
                applyColour('');
            });
        })();
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/ianjones/raynet-site/resources/views/admin/event-types/index.blade.php ENDPATH**/ ?>