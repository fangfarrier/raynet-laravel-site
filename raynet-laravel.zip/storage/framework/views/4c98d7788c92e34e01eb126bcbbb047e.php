<?php $__env->startSection('title', 'Event Support'); ?>

<?php $__env->startSection('content'); ?>
    <h1>Event Support</h1>
    <p>
        We regularly provide radio cover for charity walks, runs, parades and community events across Merseyside.
        Our operators can staff checkpoints, mobile units and a central control point to help you maintain situational
        awareness and respond quickly if something goes wrong.
    </p>
    <p>
        In the next phase, this page will include a request form so organisers can submit event details directly
        to the Group for consideration.
    </p>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/ianjones/raynet-site/resources/views/pages/event-support.blade.php ENDPATH**/ ?>